var bubs = []  
var numBubs=5;   
function setup() {
  createCanvas(600, 400);
  for(var i=0; i<numBubs; i++){
 
  bubs[i] = new Bubble(width/3,random(0, height-20),random(5, 15));
  }
}

function draw() {
background(0);
  for(var i=0; i<bubs.length; i++){
  bubs[i].show();
  bubs[i].move();
  }
  ellipse(100, 2, nums[0])
  ellipse(40, 100, nums[1])
  ellipse(19, 20, nums[2])
  ellipse(200, 200, nums[3])
  ellipse(300, 300, nums[4])
}

class nums {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
  }

  move() {
    this.x = this.x + random(-5, 5);
    this.y = this.y + random(-5, 5);
  }
  
  show() {
    stroke(255);
    strokeWeight(4);
    noFill();
    ellipse(this.x, this.y, this.r * 3);
  }
}
